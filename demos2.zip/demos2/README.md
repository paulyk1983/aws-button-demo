# Repo info
---


-   Description: Use case for Amazon IoT Button paired with Lambda Functions to execute code on demand
-   Enforce GitFlow: no


# Bosch Tool Voting Application
---

This project is an application built with [Node](https://nodejs.org/en/), [React](https://reactjs.org/), [Express](http://expressjs.com/), and [Socket.io](https://socket.io/). It also utilizes the [IoT Button](https://aws.amazon.com/iotbutton/) from Amazon, and [AWS Lambda Functions](https://aws.amazon.com/Lambda‎).


# Getting Started
---

After cloning this repository there are a few things you need to configure before you can run the application.

-   Run `sudo npm install` inside of the root folder & inside the "/client" folder

The Express server (`/index.js`) is configured to run on `localhost:5000` or `localhost:ENV_PORT` with `ENV_PORT` being which ever port is configured on the hosting enviornment before defaulting back to port `5000`. If you need to run the application on a specific port, change the `5000`.

In order for the Websockets to work between the front and back end you must configure `Line 12` of `/client/src/App.js` and change:

```
// Open client-side socket
let socket = openSocket("http://localhost:5000");
```

to match whichever domain:port configuration you are running the server from.

Once you have made all of the changes you need to `/index.js` and `/client/App.js` you MUST create a production build of the front end in order to serve static files through Express.

-   Run `sudo npm run build` inside of `/client` in order to create a production build of the front end

You may also edit the static reference to the files if needed inside of `/index.js` on `Line 26`.

```
// Static files being served as front-end
app.use(express.static(path.join(__dirname, "./client/build")));
```


# Folder Structure
---

After full build creation, the project should look like this:

```
voting-app/
    index.js
    .gitignore
    README.md
    node_modules/
    package.json
    client/
        node_modules/
        build/
            ...built static files...
        public/
            images/
                bosch_logo.png
                supergraphic.svg
            favicon.ico
            index.html
            manifest.json
            style.css
            style.min.css
            style.scss
        src/
            components/
                Header.js
                ToolHeading.js
                ToolPanel.js
            App.js
            index.js
            registerServiceWorker.js
        package.json
        .gitignore
```

For the project to build, **these files must exist with exact filenames**:

-   `/index.js` is the Server entry point;
-   `/client/public/index.html` is the page template;
-   `/client/src/index.js` is the Front end entry point;
-   `/client/src/App.js` is the main logic for the front end.

You can edit or make changes to other files, but be sure that you also make the correct corresponding edits elsewhere. I.E. an edit to the name of `/client/src/components/Header.js` would need to be changed inside `/client/src/App.js` as well.


# Available Scripts
---

In the project root directory, you can run:


## `npm start`


Runs the Server in development mode.<br>
It runs at [http://localhost:5000](http://localhost:5000) and can be accessed with adding /api/etc.


## `npm run server`


Runs the Server forever in development mode.<br>
It will run the Server at [http://localhost:5000](http://localhost:5000) and will reload and update the server on refresh.


# Available API Routes
---

These are the routes for the API that gets called by an AWS Lambda Function, they are all publically accessable.


## POST `localhost:PORT/api/vote/:number`


Can accept either `1` or `2` for the `number` param.<br>
Example: `localhost:5000/api/vote/1`

```
// POST request to /api/vote/{number}
// Called from Amazon IoT Button Lambda function
// Returns json with vote number or error message
// If containing correct number it emits a socket to the client
app.post("/api/vote/:number", (req, res) => {
    if (req.params.number > 2 || req.params.number < 1) {
        res.status(400).json({
            notAccepted: "You must send a vote for product 1 or product 2."
        });
    } else {
        res.status(200).json({ success: "true" });
        io.emit("vote", { vote: req.params.number });
        userHasVoted = true;
    }
});
```


## POST `localhost:PORT/show-results/:bool`


Can accept either `true` or `false` for the `bool` param.<br>
Example: `localhost:5000/api/show-results/true`

```
// POST request to /api/show-results/{bool}
// Called from Amazon IoT Button Lambda function
// Returns json with param or error message
// If containing true it emits a socket to the client
app.post("/api/show-results/:bool", (req, res) => {
    if (req.params.bool === "true") {
        if (userHasVoted) {
            res.status(200).json({ success: true });
            io.emit("showResults", { showResults: true });
            userHasVoted = false;
        } else {
            res.status(400).json({
                error: "User has not voted yet, please vote first."
            });
            io.emit("voteError", {
                voteError: "You must vote on a tool before showing the results."
            });
        }
    } else {
        res.status(400).json({
            mustBeTrue: "This request must be sent as true to show the results."
        });
    }
});
```


# AWS IoT Button & Lambda Function
---

In order to make full use of this application and use case you must also configure an AWS IoT button & Lambda function.

The AWS Documentation for configuring your button can be found [here](https://docs.aws.amazon.com/iot/latest/developerguide/configure-iot.html).

Once the button is configured, create a new Lambda function and attach the IoT button as a trigger for the function.

Below is the code used inside the Lambda function so that the button can be used to call the API.

You will need to configure a few things before using the code:

-   Make sure the runtime of the Lambda function is `Node.js 8.10`
-   Be sure to edit the value of `http.post` that relates to the hosting you are using for the API


## NOTE: Some common problems with AWS Lambda functions are that they fire multiple times if errors are not handled correctly and/or `callback()` is not called. We have put this functionality into the function so that it doesn't fire multiple times from one event.


```
const http = require("http");

exports.handler = (event, context, callback) => {

    if (event.clickType == "SINGLE") {
        const options = {
            host: 'ec2-18-217-100-172.us-east-2.compute.amazonaws.com',
            path: '/api/vote/1',
            port: 80,
            method: 'POST'
        };

        const req = http.request(options, (res) => {
            callback(null, "SUCCESS");
        });

        req.on('error', (e) => {
            callback(null, "ERROR");
        });

        // send the request
        req.write('');
        req.end();
    }
    else if (event.clickType == "DOUBLE") {
        const options = {
            host: 'ec2-18-217-100-172.us-east-2.compute.amazonaws.com',
            path: '/api/vote/2',
            port: 80,
            method: 'POST'
        };

        const req = http.request(options, (res) => {
            callback(null, "SUCCESS");
        });

        req.on('error', (e) => {
            callback(null, "ERROR");
        });

        // send the request
        req.write('');
        req.end();
    }
    else {
        const options = {
            host: 'ec2-18-217-100-172.us-east-2.compute.amazonaws.com',
            path: '/api/show-results/true',
            port: 80,
            method: 'POST'
        };

        const req = http.request(options, (res) => {
            callback(null, "SUCCESS");
        });

        req.on('error', (e) => {
            callback(null, "ERROR");
        });

        // send the request
        req.write('');
        req.end();
    }
};
```


# PuTTY Configuration
---

In order to SSH into your AWS hosting instance your PuTTY client needs to have the Proxy configuration and SSH Keypair correct.


## Proxy


Inside PuTTY navigate to Connection -> Proxy and select `HTTP` and enter the hostname `rb-proxy-na.bosch.com`, the port `8080`, and your computers `Username` & `Password` to be able to correctly connect to the AWS instance.


## Keypair

The PuTTY .ppk file we used for our AWS Instance during testing is included in the repository `votingKeypair.ppk`.

When you are setting your AWS instance up you will need to generate and save a .pem file, take this file and `load` it into PuTTYgen to generate a `RSA` .ppk file that is compatible with PuTTY. Once you have the correct .ppk file, navigate to Connection -> SSH -> Auth and where it says `Private key file for authentication:` browse and select the correct .ppk file for your AWS instance.

# Bosch Developer API Access
---

In order to communicate with the Bosch Developer APIs that are called from the front-end you must log in to the [Bosch Developer Website](https://developer.bosch.com) and generate an API key for both the Product API, and the Ratings and Reviews API. Once you have the corresponding keys you need to edit all of the headers inside of `client/src/App.js` within the axios get calls:

The header for the Bosch Developer API Key is `KeyId: "***********************",`

```
axios({
    url:
        "https://ews-emea.api.bosch.com/pim/product-catalog/products/6200_6942501770232?dataset=full",
    method: "get",
    headers: {
        KeyId: "***********************",
        "Content-Type": "application/json"
    }
})
.then(response => {
    console.log(response.data);
    this.setState({
        product1: {
            image: response.data.data.mediaAssets.mainImage.toString(),
            name: response.data.data.marketingData.name.toString(),
            loading: false,
            id: 1
        }
    });
})
.catch(err => {
    console.log(err);
});
```


# CORS
---

In order for the websockets to be able to communicate from client to server the CORS npm package must be required and used in `index.js`. This should not be a problem as it is included by default with this application.


# Additional References
---

While building this application we relied on a few sources of documentation and references that may be helpful to anyone using this in the future.

-   [React Documentation](https://reactjs.org/docs/getting-started.html)
-   [ExpressJS Guides & API References](http://expressjs.com/)
-   [Socket.io Documentation](https://socket.io/docs/)
-   [Create React App Documentation](https://github.com/facebook/create-react-app)


# Contributors
---

-   Brett Kubiak (CI/DAD2.2) fixed-term.Brett.Kubiak@us.bosch.com
-   Janice Fang (CI/DAD2.2) fixed-term.Janice.Fang@us.bosch.com
