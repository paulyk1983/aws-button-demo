import React from "react";

const ratingsToStars = (stars) => {
    let starCount = "";

    let hasHalfStar = (stars % 1) === 0.5;
    let starsToAdd = 0;

    if (hasHalfStar) {
        starsToAdd = (stars - 0.5);
        for (let i = 0; i < starsToAdd; i++) {
            starCount += "<i class='fas fa-star'></i>";
        }
        starCount += "<i class='fas fa-star-half-alt'></i>";
    } else {
        for (let i = 0; i < stars; i++) {
            starCount += "<i class='fas fa-star'></i>";
        }
    }

    console.log(starCount);

    const content = () => {
        return { __html: starCount };
    }

    // This is not good practice for a real-world production application
    // More info on dangerouslySetInnerHTML: https://reactjs.org/docs/dom-elements.html#dangerouslysetinnerhtml
    return (
        <div className="ratingStars" dangerouslySetInnerHTML={content()} />
    );
}

const ToolPanel = props => {
    return (
        <div
            className={
                props.product.lowopp
                    ? props.show
                        ? "tool-holder"
                        : "tool-holder lowopp"
                    : "tool-holder"
            }
        >
            <h3 className="text-center vote-text">
                <div>{props.product.name}</div><br />
            </h3>
            <div
                className={
                    props.product.selected
                        ? props.show
                            ? "tool-panel"
                            : "tool-panel selected"
                        : "tool-panel"
                }
            >
                {props.product.loading ? (
                    <div className="spinner" />
                ) : (
                        <div>
                            <img
                                src={props.product.image}
                                width="100%"
                                height="200px"
                                alt="tool"
                            />
                        </div>
                    )}
            </div>
            {!props.show && (
                <h4 className="text-center vote-text text-muted">
                    {!props.product.selected ? (
                        !props.product.loading ? (
                            props.product.id > 1 ? (
                                <div>
                                    Click {props.product.id} times to vote for
                                    this tool.
                                </div>
                            ) : (
                                    <div>
                                        Click {props.product.id} time to vote for
                                        this tool.
                                </div>
                                )
                        ) : (
                                <div>Loading...</div>
                            )
                    ) : (
                            <div>You have selected this tool.</div>
                        )}
                </h4>
            )}
            {props.show && (
                <h3 className="text-center vote-text text-muted">
                    <div>Average Rating: {ratingsToStars(props.rating.averageRating)} ({props.rating.averageRating})</div>
                    <div className="mt-10">{props.rating.numOfRatings} Total Ratings</div>
                </h3>
            )}
        </div>
    );
};

export default ToolPanel;
