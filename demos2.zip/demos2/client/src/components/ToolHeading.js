import React from "react";

const ToolHeading = props => {
    return (
        <div className="tool-heading">
            <div className="row">
                <div className="col-xs-12 tool-heading__title text-center">
                    {props.show ? (
                        props.correct ? (
                            <h1 className="correct">You were correct!</h1>
                        ) : (
                            <h1 className="incorrect">You were incorrect.</h1>
                        )
                    ) : (
                        <h1>Vote on which tool you think is more popular!</h1>
                    )}
                </div>
            </div>
            {!props.show && (
                <div className="row mt-10">
                    <div className="col-xs-12 heading-sub text-center text-muted">
                        Use the AWS IoT Button in order to vote. Once you have
                        casted your vote hold the button down for 4 seconds in
                        order to reveal which product is more popular.
                    </div>
                </div>
            )}
            {props.show && (
                <div className="row mt-10">
                    <div className="col-xs-12 heading-sub text-center text-muted">
                        Refresh the page (F5) to restart!
                    </div>
                </div>
            )}
        </div>
    );
};

export default ToolHeading;
