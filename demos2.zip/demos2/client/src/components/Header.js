import React from "react";

const Header = props => {
    return (
        <div>
            <div className="supergraphic" />
            <div className="header">
                <div className="header__logo">
                    <img src="./images/bosch_logo.png" alt="logo" />
                </div>
                <div className="header__title">Tool Voting Application</div>
            </div>
            <div className={props.errors.showErrors ? "errors show" : "errors"}>
                <p>Error: {props.errors.voteError}</p>
            </div>
        </div>
    );
};
export default Header;
