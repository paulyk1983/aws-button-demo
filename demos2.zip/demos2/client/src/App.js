// Main Imports
import React, { Component } from "react";
import openSocket from "socket.io-client";
import axios from "axios";

// Component Imports
import ToolPanel from "./components/ToolPanel";
import ToolHeading from "./components/ToolHeading";
import Header from "./components/Header";

// Open client-side socket
let socket = openSocket("http://localhost:5000");

// App class
class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            product1: {
                id: 1,
                name: "",
                image: "",
                loading: true,
                selected: false,
                lowopp: false
            },
            product2: {
                id: 2,
                name: "",
                image: "",
                loading: true,
                selected: false,
                lowopp: false
            },
            errors: {
                showErrors: false,
                voteError: ""
            },
            rating1: {
                averageRating: 0,
                numOfRatings: 0
            },
            rating2: {
                averageRating: 0,
                numOfRatings: 0
            },
            showResults: false,
            highestRating: 0,
            isCorrect: false
        };
    }

    // Called when the component (App) is finished mounting to the DOM
    componentWillUnmount() {
        // Clears the timer on the error popup so it goes away after 7 seconds
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
        }
    }



    // Called when the component (App) is mounted to the DOM
    componentDidMount() {
        // Update state when socket is passed to client
        socket.on("vote", data => {
            if (this.state.showResults) {
                return;
            } else {
                if (data.vote === "1") {
                    if (this.state.highestRating === 1) {
                        this.setState({
                            isCorrect: true
                        });
                    } else {
                        this.setState({
                            isCorrect: false
                        });
                    }
                    this.setState({
                        product1: {
                            image: this.state.product1.image,
                            name: this.state.product1.name,
                            id: 1,
                            selected: true,
                            lowopp: false
                        },
                        product2: {
                            image: this.state.product2.image,
                            name: this.state.product2.name,
                            id: 2,
                            selected: false,
                            lowopp: true
                        },
                        errors: {
                            showErrors: false
                        }
                    });
                    console.log(this.state.isCorrect);
                } else if (data.vote === "2") {
                    if (this.state.highestRating === 2) {
                        this.setState({
                            isCorrect: true
                        });
                    } else {
                        this.setState({
                            isCorrect: false
                        });
                    }
                    this.setState({
                        product1: {
                            image: this.state.product1.image,
                            name: this.state.product1.name,
                            id: 1,
                            selected: false,
                            lowopp: true
                        },
                        product2: {
                            image: this.state.product2.image,
                            name: this.state.product2.name,
                            id: 2,
                            selected: true,
                            lowopp: false
                        },
                        errors: {
                            showErrors: false
                        }
                    });
                    console.log(this.state.isCorrect);
                } else {
                    return;
                }
            }
        });

        // Error message pops in for 7 seconds
        socket.on("voteError", data => {
            this.setState({
                errors: {
                    showErrors: true,
                    voteError: data.voteError
                }
            });
            this.timeoutId = setTimeout(() => {
                this.setState({
                    errors: {
                        showErrors: false,
                        voteError: data.voteError
                    }
                });
            }, 7000);
        });

        // Show the results of the voting
        socket.on("showResults", data => {
            this.setState({
                showResults: data.showResults
            });
            console.log(this.state.showResults);
        });

        // Pull product 1 ratings
        axios({
            url:
                "https://ews-emea.api.bosch.com/pim/rating-management/ratings/items/6200_6942501770232",
            method: "get",
            headers: {
                KeyId: "d113e1d0-05b6-47c6-bb38-4b6a7ebcdd88",
                "Content-Type": "application/json"
            }
        })
            .then(response => {
                console.log(response);
                this.setState({
                    rating1: {
                        averageRating: response.data.data.averageRating,
                        numOfRatings: response.data.data.numOfRatings
                    }
                });
            })
            .catch(err => {
                console.log(err);
            });

        // Pull product 2 ratings
        axios({
            url:
                "https://ews-emea.api.bosch.com/pim/rating-management/ratings/items/6200_6942501770331",
            method: "get",
            headers: {
                KeyId: "d113e1d0-05b6-47c6-bb38-4b6a7ebcdd88",
                "Content-Type": "application/json"
            }
        })
            .then(response => {
                console.log(response);
                this.setState({
                    rating2: {
                        averageRating: response.data.data.averageRating,
                        numOfRatings: response.data.data.numOfRatings
                    }
                });
                // Find which product has the higher rating
                if (
                    this.state.rating1.averageRating >
                    this.state.rating2.averageRating
                ) {
                    console.log("product 1 has highest rating");
                    this.setState({
                        highestRating: 1
                    });
                } else if (
                    this.state.rating1.averageRating <
                    this.state.rating2.averageRating
                ) {
                    console.log("product 2 has highest rating");
                    this.setState({
                        highestRating: 2
                    });
                } else {
                    // The same rating
                    console.log("The ratings are the same.");
                }
            })
            .catch(err => {
                console.log(err);
            });

        // Pull product 1 image from products API
        axios({
            url:
                "https://ews-emea.api.bosch.com/pim/product-catalog/products/6200_6942501770232?dataset=full",
            method: "get",
            headers: {
                KeyId: "d113e1d0-05b6-47c6-bb38-4b6a7ebcdd88",
                "Content-Type": "application/json"
            }
        })
            .then(response => {
                console.log(response.data);
                this.setState({
                    product1: {
                        image: response.data.data.mediaAssets.mainImage.toString(),
                        name: response.data.data.marketingData.name.toString(),
                        loading: false,
                        id: 1
                    }
                });
            })
            .catch(err => {
                console.log(err);
            });

        // Pull product 2 image from products API
        axios({
            url:
                "https://ews-emea.api.bosch.com/pim/product-catalog/products/6200_6942501770331?dataset=full",
            method: "get",
            headers: {
                KeyId: "d113e1d0-05b6-47c6-bb38-4b6a7ebcdd88",
                "Content-Type": "application/json"
            }
        })
            .then(response => {
                this.setState({
                    product2: {
                        image: response.data.data.mediaAssets.mainImage.toString(),
                        name: response.data.data.marketingData.name.toString(),
                        loading: false,
                        id: 2
                    }
                });
            })
            .catch(err => {
                console.log(err);
            });
    }

    render() {
        return (
            <div className="main">
                <Header errors={this.state.errors} />
                <div className="ratings">
                    <ToolHeading
                        correct={this.state.isCorrect}
                        show={this.state.showResults}
                    />
                    <div className="row mt-20">
                        <div className="col-xs-12 col-sm-5 col-md-5">
                            <ToolPanel
                                product={this.state.product1}
                                rating={this.state.rating1}
                                show={this.state.showResults}
                            />
                        </div>
                        <div className="col-xs-12 col-md-offset-2 col-sm-5 col-sm-offset-2 col-md-5">
                            <ToolPanel
                                product={this.state.product2}
                                rating={this.state.rating2}
                                show={this.state.showResults}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default App;
