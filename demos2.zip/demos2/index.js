//---MAIN DECLARATIONS---//

const express = require("express");
const app = express();
const server = require("http").Server(app);
const io = require("socket.io")(server);
const cors = require("cors");
const bodyParser = require("body-parser");
const helmet = require("helmet");
const path = require("path");
const port = process.env.PORT || 5000;

//---MIDDLEWARE---//

let userHasVoted = false;

// CORS Fix (For websockets running on same port in production)
app.use(cors());

// Helmet (API Security)
app.use(helmet());

// Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Static files being served as front-end
app.use(express.static(path.join(__dirname, "./client/build")));

//---------------//

// Start API Server & Back-end sockets
server.listen(port, () => console.log(`Server listening on port ${port}`));

// POST request to /api/vote/{number}
// Called from Amazon IoT Button Lambda function
// Returns json with vote number or error message
// If containing correct number it emits a socket to the client
app.post("/api/vote/:number", (req, res) => {
    if (req.params.number > 2 || req.params.number < 1) {
        res.status(400).json({
            notAccepted: "You must send a vote for product 1 or product 2."
        });
    } else {
        res.status(200).json({ success: "true" });
        io.emit("vote", { vote: req.params.number });
        userHasVoted = true;
    }
});

// POST request to /api/show-results/{bool}
// Called from Amazon IoT Button Lambda function
// Returns json with param or error message
// If containing true it emits a socket to the client
app.post("/api/show-results/:bool", (req, res) => {
    if (req.params.bool === "true") {
        if (userHasVoted) {
            res.status(200).json({ success: true });
            io.emit("showResults", { showResults: true });
            userHasVoted = false;
        } else {
            res.status(400).json({
                error: "User has not voted yet, please vote first."
            });
            io.emit("voteError", {
                voteError: "You must vote on a tool before showing the results."
            });
        }
    } else {
        res.status(400).json({
            mustBeTrue: "This request must be sent as true to show the results."
        });
    }
});
